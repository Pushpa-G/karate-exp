function fn() {
    var env = karate.env;
    
    if (!env){
		env = 'dev';
	}

    var config = {
		env : env,
		myVarName : "Sen. Trilochana Sethi",
		baseUrl : 'https://gorest.co.in',
		authToken : '1cb970fad0b4cbc715390d901ba697c4f225b1d2aec6f48bc75e06c7c497c434'
	}


    return config;
}
